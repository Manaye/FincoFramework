package framework;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;


import model.Account;


public class ObservableImpl implements Observable {

	Collection<Observer> observersList = new ArrayList<>();
	public ObservableImpl() {
		
	}
	@Override
	public void register(Observer observer) {
		// TODO Auto-generated method stub
		observersList.add(observer);
	}

	@Override
	public void remove(Observer observer) {
		// TODO Auto-generated method stub
		observersList.remove(observer);
	}

	@Override
	public void notifyObservers(Account account) {
		// TODO Auto-generated method stub
		for(Observer observers : observersList) {
			observers.update(account);
		}
	}

}
