package framework;

import model.Account;

public interface Observer {
	void update(Account account);
}
