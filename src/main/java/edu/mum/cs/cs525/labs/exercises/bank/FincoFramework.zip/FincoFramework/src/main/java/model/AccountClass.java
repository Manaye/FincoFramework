package model;

public enum AccountClass {
	PERSONAL, COMPANY, CREDITCARD
}
