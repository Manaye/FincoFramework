package model;

public enum CreditCardType {
    GOLD, SILVER, BRONZE
}
