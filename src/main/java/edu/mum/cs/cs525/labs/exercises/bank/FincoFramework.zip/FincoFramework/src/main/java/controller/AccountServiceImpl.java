package controller;

import dao.AccountDAO;
import dao.AccountDAOImpl;
import framework.Observable;
import framework.Observer;
import model.*;
import observers.EmailSender;
import observers.Logger;
import observers.SMSSender;

import java.time.LocalDate;
import java.util.Collection;
//import java.util.Observer;

public class AccountServiceImpl implements AccountService {
	private AccountDAO accountDAO;
	 Observer observer;
	 Observable observable;
	 //Collection<Observer> observers;
	

	public AccountServiceImpl(Observable observable) {
		accountDAO = new AccountDAOImpl();
		this.observable = observable;
		

	}

	public Account createCreditAccount(String accountNumber, String customerName, String email, String street, String city,
			String state, String zip, String creditCardNumber, LocalDate expiredDate,  CreditCardType ccType,  AccountClass accountclass) {
		
		Account account = new Account(accountNumber, AccountClass.CREDITCARD);
		switch (ccType) {
		case GOLD:
			account = new GoldCreditCard(accountNumber, creditCardNumber, expiredDate);
			break;
		case SILVER:
			account = new SilverCreditCard(accountNumber, creditCardNumber, expiredDate);
			break;
		default:
			account = new BronzeCreditCard(accountNumber, creditCardNumber, expiredDate);
		}

		Address address = new Address(street, city, state, zip);
		Customer customer = new Customer(customerName, email, address);
		account.setCustomer(customer);


		accountDAO.saveAccount(account);
		return account;
	}
	public Account createPersonalAccount(String accountNumber, String name, AccountType accountType, String street, 
			String city, String state, String zip, String email, LocalDate birthdate, AccountClass accountclass) {
		
		Account account = new Account(accountNumber, accountType, AccountClass.PERSONAL);
		Address address = new Address(street, city, state, zip);
		Customer customer = new Customer(name, email, address);
		
		account.setCustomer(customer);
		accountDAO.saveAccount(account);
		//account.addObserver(emailSender);
		
		return account;
	}
	//String accountNumber, AccountType accountType, AccountClass accountClass
	public Account createCompanyAccount(String accountNumber, String name, AccountType accountType, String street, 
			String city, String state, String zip, String email, int numEmployees, AccountClass accountclass) {
		
		Account account = new Account(accountNumber, accountType, AccountClass.COMPANY);
		Address address = new Address(street, city, state, zip);
		Customer customer = new Customer(name, email, address);
		
		account.setCustomer(customer);
		accountDAO.saveAccount(account);
		//account.addObserver(emailSender);
		
		return account;
	}


	

	public void deposit(String accountNumber, double amount) {
		Account account = accountDAO.loadAccount(accountNumber);
		account.deposit(amount);
		observable.notifyObservers(account);
		accountDAO.updateAccount(account);
	}

	public Account getAccount(String accountNumber) {
		Account account = accountDAO.loadAccount(accountNumber);
		return account;
	}

	public Collection<Account> getAllAccounts() {
		return accountDAO.getAccounts();
	}

	public void withdraw(String accountNumber, double amount) {
		Account account = accountDAO.loadAccount(accountNumber);
		account.withdraw(amount);
		accountDAO.updateAccount(account);

		if (amount > 400) {
			account.notifyChanged();
		}
	}

	public void addInterest() {
		for (Account account : this.getAllAccounts()) {
			account.addInterest();
		}
	}

	public void getBillingReport() {
		// TODO
	}
}
