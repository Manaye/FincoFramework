package observers;

import javax.swing.JOptionPane;

import framework.Observable;
import framework.Observer;
import model.Account;

public class EmailSender implements Observer {

    Observable observable;
	public EmailSender(Observable observable) {
			this.observable = observable;
			observable.register(this);
		}
	@Override
	public void update(Account account) {
		// TODO Auto-generated method stub
		System.out.println("Test1:" + account.getBalance());
		String str = account.getBalance() +  " has been added to account " + account.getAccountNumber()
		+ " is created ";
		JOptionPane.showMessageDialog(null, "Email Sent",str, 0);
        
	}
   
}
