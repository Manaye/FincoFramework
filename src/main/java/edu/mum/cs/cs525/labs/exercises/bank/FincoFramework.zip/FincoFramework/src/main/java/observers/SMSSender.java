package observers;

import javax.swing.JOptionPane;

import framework.Observable;
import framework.Observer;
import model.Account;

public class SMSSender implements Observer {

	 Observable observable;
		public SMSSender(Observable observable) {
				this.observable = observable;
				observable.register(this);
			}
	@Override
	public void update(Account account) {
		// TODO Auto-generated method stub
		String str = account.getBalance() +  " has been added to account " + account.getAccountNumber()
		+ " is created ";
		JOptionPane.showMessageDialog(null, "SMS Sent",str, 0);
	}
  
}
