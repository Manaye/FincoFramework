package model;

public class CheckingAccount {

}
