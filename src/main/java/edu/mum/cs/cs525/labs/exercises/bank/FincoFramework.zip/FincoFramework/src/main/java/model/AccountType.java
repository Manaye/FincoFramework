package model;

public enum AccountType {
	SAVING, CHECKING
}
