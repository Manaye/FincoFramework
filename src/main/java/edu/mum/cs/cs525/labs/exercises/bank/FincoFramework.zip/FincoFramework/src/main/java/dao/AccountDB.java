package dao;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;

import model.Account;
import model.CreditCardType;


public class AccountDB {
	
	public static Collection<Account> accountlist = new ArrayList<>();
	
	//Account accountOne = new Account("123456", );
	
//	Account accountTwo = new CreditCard("67589");

}
