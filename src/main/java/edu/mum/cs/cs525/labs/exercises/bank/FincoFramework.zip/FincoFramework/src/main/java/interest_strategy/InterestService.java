package interest_strategy;

public interface InterestService {
    double calInterest(double balance);
    double caclMinPayment(double balance);
}
